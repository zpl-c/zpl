Should be placed under zpl/build directory.

I will try to keep it up-to-date, however project also might refer to files that are absent from the repository, 
I recommend either cleaning those up or downloading them (they are usually third-parties).

Note this project shouldn't be taken as a template nor library to be used within your own VS solution. 
It's purely only a workspace used during the development and serves no production purpose whatsoever.