#define ZPL_IMPLEMENTATION
#include <zpl.h>

int main() {
    return 0;
}