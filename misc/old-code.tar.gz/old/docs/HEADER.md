<div align="center">
    <a href="https://github.com/zpl-c/zpl"><img src="https://user-images.githubusercontent.com/9026786/43263060-7c0a8b86-90e2-11e8-96e3-3e71e559f62a.png" alt="zpl" /></a>
</div>

<div align="center">
    <a href="https://travis-ci.org/zpl-c/zpl"><img src="https://travis-ci.org/zpl-c/zpl.svg?branch=master" alt="Build status" /></a>
    <a href="https://www.npmjs.com/package/zpl.c"><img src="https://img.shields.io/npm/v/zpl.c.svg?maxAge=3600" alt="NPM version" /></a>
    <a href="https://discord.gg/2fZVEym"><img src="https://discordapp.com/api/guilds/354670964400848898/embed.png" alt="Discord server" /></a>
</div>

<br />
<div align="center">
  C99 cross-platform header-only library that offers powerful toolkit to accelerate your development progress.
</div>

<div align="center">
  <sub>
    Brought to you by <a href="https://github.com/zaklaus">@zaklaus</a>, 
     <a href="https://github.com/inlife">@inlife</a>,
    and <strong>contributors</strong>
  </sub>
</div>
 
